<?php
    $token_number = $_GET['Token_Number'];
    $conn = Mysqli_connect("localhost","root","","parking_project") or die("conection failed");
    $sql = "SELECT * FROM vehicle_info where Token_Number = '{$token_number}'";
    $result = mysqli_query($conn, $sql) or die("Query failed!");
    if(mysqli_num_rows($result)>0){
        while ($row = mysqli_fetch_assoc($result)){
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IF=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System</title>
    <link rel="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvINh0E263XmFcJISAwiGgFAW/dAiS6JXm" crossorigin="an">
     <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
    <div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 text-center" align="center" id="header">
                    <h1>Parking Management System</h1>
                </div>
            </div>
        </div>
        <div class="container">
                <div class="row">
                    <div class="col-md-6 text-center mb-3" align="center">
                        <h2 class="register">Update Exit Date Form</h2>
                        <form action="updatesave.php" method="post">
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="owner">Vehicle Owner Name:</span>
                            </div>
                            <input class="a" type="text" name="owner_name" value="<?php echo $row['Owner_Name'];?>" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Vehicle Name:</span>
                            </div>
                            <input class="a" type="text" name="vehicle_name" value="<?php echo $row['Vehicle_Name'];?>" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Vehicle Number:</span>
                            </div>
                            <input class="a" type="text" name="vehicle_number" value="<?php echo $row['Vehicle_Number'];?>" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Entry Date:</span>
                            </div>
                            <input class="a" type="text" name="entry_date" value="<?php echo $row['Entry_Date'];?>" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Exit Date:</span>
                            </div>
                            <input class="a" type="datetime-local" name="exit_date" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Token Number:</span>
                            </div>
                            <input class="a" type="number" name="Token" value="<?php echo $row['Token_Number'];?>" class="form-control">
                        </div><br>
                        <input class="b"  type="submit" onclick="click()" class="btn btn-prrimary mt-3">
                        </form>
                    </div>
                </div>
            </div>

        </div>
</body>
</html>

<?php
        }
    }else{
        echo "No Data Found!";
    }
?>
