<?php

echo $Token_number = $_GET['Token_Number'];

    $conn = Mysqli_connect("localhost","root","","parking_project") or die("conection failed");
    $sql = "DELETE FROM vehicle_info where Token_Number = '{$Token_Number}'";
    $result = mysqli_query($conn, $sql) or die("query Failed");
    header("location: http://localhost/parkingmanagementsystem/index.php");
    mysqli_close($conn);
?>