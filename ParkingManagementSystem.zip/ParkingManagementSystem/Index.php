<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IF=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System</title>
    <link rel="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvINh0E263XmFcJISAwiGgFAW/dAiS6JXm" crossorigin="an">
     <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
    <div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 text-center" align="center" id="header">
                    <h1>Parking Management System</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="record.php">All Records</a></li>
                        <li><a href="admin.php">Make Parking Admin</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container">
                <div class="row">
                    <div class="col-md-6 text-center mb-3" align="center">
                        <h2 class="register">Registeration Form</h2>
                        <form action="save.php" method="post">
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="owner">Vehicle Owner Name:</span>
                            </div>
                            <input class="a" type="text" name="owner_name" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Vehicle Name:</span>
                            </div>
                            <input class="a" type="text" name="vehicle_name" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Vehicle Number:</span>
                            </div>
                            <input class="a" type="text" name="vehicle_number" class="form-control">
                        </div><br>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Entry Date:</span>
                            </div>
                            <input class="a" type="datetime-local" name="entry_date" class="form-control">
                        </div><br>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-number">Token Number:</span>
                            </div>
                            <input class="a" type="number" name="token_number" class="form-control">
                        </div><br>
                        <input class="b"  type="submit" onclick="click()" class="btn btn-prrimary mt-3">
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <section>
            <div class="container">
                <div class="row">
                    <div align="center">
                        <h2 class="register1">All Vehicle Entry Records</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="input-group" align="center">
                            <span class="input-group-text">Search:</span>
                            <input class="c" type="text" onkeyup="search()" id="text" placeholder="Search Vehicle Details">
                        </div><br>
                    <center>
                        <table border="1" width="70%" class="table table-striped" id="table">
                            <?php
                                $conn = Mysqli_connect("localhost","root","","parking_project") or die("conection failed");
                                $sql = "SELECT * FROM Vehicle_info";
                                $result = mysqli_query($conn, $sql) or die("query Failed");
                                if(mysqli_num_rows($result)>0){
                                    ?>
                            <thead>
                                <tr align="center">
                                    <th>Owner Name</th>
                                    <th>Vehicle Name</th>
                                    <th>Vehicle Number</th>
                                    <th>Entry Date</th>
                                    <th>Token Number</th>
                                    <th>Update Record</th>
                                    <th>Delete Record</th>
                                </tr>
                            </thead>
                            <?php
                            while($row = mysqli_fetch_assoc($result)){
                            ?>
                            
                            <tbody>
                                <tr align="center">
                                    <td><?php echo $row['Owner_Name'];?></td>
                                    <td><?php echo $row['Vehicle_Name'];?></td>
                                    <td><?php echo $row['Vehicle_Number'];?></td>
                                    <td><?php echo $row['Entry_Date'];?></td>
                                    <td><?php echo $row['Token_Number'];?></td>
                                    <td><a href="update.php?Token_Number=<?php echo $row['Token_Number']?>">Exit Date</a></td>
                                    <td><a href="delete-inline.php?Token_Number=<?php echo $row['Token_Number']?>">Delete</a></td>
                                </tr>
                            </tbody>
                            <?php
                            }
                            ?>
                        </table>
                        <?php
                        }else{
                            echo "No Data Found!";
                        }
                            ?>
                    </center>
                </div>
            </div>
        </div>
    </section>
    <script>
        const search = () =>{
            var input_value = document.getElementById("text").value.toUpperCase();
            var table = document.getElementById("table");
            var tr = table.getElementsByTagName("tr");
            for(var i =0; i<tr.length; i++){
                td = tr[i].getElementsByTagName("td")[0];
                
                if(td){
                    var text_value = td.textContent;
                    if(text_value.toUpperCase().indexOf(input_value)>-1){
                        tr[i].style.display = "";
                    }else{
                        tr[i].style.display= "none";
                    }
                }
            }
        }
    </script>
</body>
</html>