<?php
$Username = $_POST['Username'];
$Password = $_POST['Password'];
$Co_pass = $_POST['Co-password'];
if($Password == $Co_pass){
	$conn = mysqli_connect("localhost", "root", "", "login_info") or die("connection failed!");
	$SQL = "SELECT * FROM admin_info where Username = '{$Username}' && Password = '{$Password}'";
	$result = mysqli_query($conn,$SQL) or die("query failed!");
	$num = mysqli_num_rows($result);
	if($num == 1){
		echo "Your have already exit in database";
	}else{
		$sql = "INSERT INTO admin_info(Username, Password) VALUES ('{$Username}', '{$Password}')";
		$result = mysqli_query($conn, $sql) or die("query failed!");
		mysqli_close($conn);
		header("location:http://localhost/parkingmanagementsystem/index.php");
	}
}else{
	echo "Your Confirm and password is not same!";
}
?>