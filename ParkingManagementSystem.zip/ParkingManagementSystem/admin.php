<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IF=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System</title>
    <link rel="stylesheet" href="abc.css">
</head>
<body>
    <div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 text-center" align="center" id="header">
                    <h1>Parking Management System</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="record.php">All Records</a></li>
                        <li><a href="admin.php">Make Parking Admin</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
        <div class="form">
            <div class="admin-form">
                <h1>Admin Form</h1>
                <form action="registration.php" method="post">
                    <label for="">Username:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    <input type="taxt" name="Username" placeholder="Username"><br><br>
                    <label for="">Password:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    <input type="taxt" name="Password" placeholder="Password"><br><br>
                    <label>Confirm Password:</label>&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="taxt" name="Co-password" placeholder="Confirm Password"><br><br>
                    <input type="submit" class="submit" value="submit">
                </form>
            </div>
        </div>
</body>
</html>