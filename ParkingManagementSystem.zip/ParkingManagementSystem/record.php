<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IF=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Management System</title>
    <link rel="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvINh0E263XmFcJISAwiGgFAW/dAiS6JXm" crossorigin="an">
     <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 text-center" align="center" id="header">
                    <h1>Parking Management System</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="record.php">All Records</a></li>
                        <li><a href="admin.php">Make Parking Admin</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <section>
            <div class="container">
                <div class="row">
                    <div align="center">
                        <h2 class="register2">All Vehicle Entry and Exit Records</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="input-group" align="center">
                            <span class="input-group-text">Search:</span>
                            <input class="c" type="text" onkeyup="search()" id="text" placeholder="Search Vehicle Details">
                        </div><br>
                    <center>
                        <table border="1" width="70%" class="table table-striped" id="table">

                            <?php
                                $conn = Mysqli_connect("localhost","root","","parking_update_info") or die("conection failed");
                                $sql = "SELECT * FROM update_info";
                                $result = mysqli_query($conn, $sql) or die("query Failed");
                                if(mysqli_num_rows($result)>0){
                            ?>

                            <thead>
                                <tr align="center">
                                    <th>Owner Name</th>
                                    <th>Vehicle Name</th>
                                    <th>Vehicle Number</th>
                                    <th>Entry Date</th>
                                    <th>Exit Date</th>
                                    <th>Token Number</th>
                                    <th>Delete Record</th>
                                </tr>
                            </thead>
                            <?php
                            while($row = mysqli_fetch_assoc($result)){
                            ?>
                            
                            <tbody>
                                <tr align="center">
                                    <td><?php echo $row['Owner_Name'];?></td>
                                    <td><?php echo $row['Vehicle_Name'];?></td>
                                    <td><?php echo $row['Vehicle_Number'];?></td>
                                    <td><?php echo $row['Entry_Date'];?></td>
                                    <td><?php echo $row['Exit_Date'];?></td>
                                    <td><?php echo $row['Token_Number'];?></td>
                                    <td><a href="delete-update.php?Entry_Date=<?php echo $row['Entry_Date']?>">Delete</a></td>
                                </tr>
                            </tbody>
                            <?php
                            }
                            ?>
                        </table>
                        <?php
                        }else{
                            echo "No Data Found!";
                        }
                            ?>
                    </center>
                </div>
            </div>
        </div>
    </section>
    <script>
        const search = () =>{
            var input_value = document.getElementById("text").value.toUpperCase();
            var table = document.getElementById("table");
            var tr = table.getElementsByTagName("tr");
            for(var i =0; i<tr.length; i++){
                td = tr[i].getElementsByTagName("td")[0];
                
                if(td){
                    var text_value = td.textContent;
                    if(text_value.toUpperCase().indexOf(input_value)>-1){
                        tr[i].style.display = ""
                    }else{
                        tr[i].style.display= "none";
                    }
                }
            }
        }
    </script>
</body>
</html>