<?php

echo $Entry_Date = $_GET['Entry_Date'];

    $conn = Mysqli_connect("localhost","root","","parking_update_info") or die("conection failed");
    $sql = "DELETE FROM update_info where Entry_Date = '{$Entry_Date}'";
    $result = mysqli_query($conn, $sql) or die("query Failed");
    header("location: http://localhost/parkingmanagementsystem/record.php");
    mysqli_close($conn);
?>